struct Splat {
    pos: vec2<f32>,
    size: u32,
    color_rg: u32,
    color_b_opacity: u32,
    conic_x: f32,
    conic_y: f32,
    conic_z: f32,
};

@group(0) @binding(0)
var<storage, read> splats: array<Splat>;
@group(0) @binding(1)
var<storage, read> sort_indices: array<u32>;

struct VertexOutput {
    @builtin(position) position: vec4<f32>,
    @location(0) color: vec4<f32>,
};

@vertex
fn vs_main(
    @builtin(vertex_index) vid: u32,      // 0..3  -> quad corner
    @builtin(instance_index) iid: u32,    // 0..keys_size-1, already depth-sorted
) -> VertexOutput {
    let splat = splats[sort_indices[iid]];

    // triangle-strip corners: 0:(-1,-1) 1:(1,-1) 2:(-1,1) 3:(1,1)
    let corner = vec2<f32>(f32(vid & 1u) * 2.0 - 1.0, f32(vid >> 1u) * 2.0 - 1.0);
    let size = unpack2x16float(splat.size);

    var out: VertexOutput;
    out.position = vec4<f32>(splat.pos + corner * size, 0.0, 1.0);
    out.color = vec4<f32>(unpack2x16float(splat.color_rg), unpack2x16float(splat.color_b_opacity));
    return out;
}

@fragment
fn fs_main(in: VertexOutput) -> @location(0) vec4<f32> {
    return in.color;
}